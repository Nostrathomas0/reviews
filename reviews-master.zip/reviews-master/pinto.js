// https://manuel.pinto.dev
